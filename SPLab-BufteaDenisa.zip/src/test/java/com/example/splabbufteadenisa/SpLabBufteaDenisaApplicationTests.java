package com.example.splabbufteadenisa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpLabBufteaDenisaApplicationTests {

//    @Test
//    void contextLoads() {
//    }

}
